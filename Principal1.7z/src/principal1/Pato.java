/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package principal1;

/**
 *
 * @author sala3
 */
public class Pato extends Servivo {
    
    public Pato (){
    super ();
    }
    
    public void comunicarse (){
        System.out.println("Quak Quak... ");
    }
}
